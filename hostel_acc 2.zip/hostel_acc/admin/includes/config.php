<?php
$dbuser="immanuel";
$dbpass="12081991";
$host="db4free.net:3306";
$db="immanuel";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>
