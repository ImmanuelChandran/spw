<?php
$DB_host = "db4free.net:3306";
$DB_user = "immanuel";
$DB_pass = "12081991";
$DB_name = "immanuel";
try
{
 $DB_con = new PDO("mysql:host={$DB_host};dbname={$DB_name}",$DB_user,$DB_pass);
 $DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e)
{
 $e->getMessage();
}
?>
